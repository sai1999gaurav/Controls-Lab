Mp = 0.027;
lp = 0.153;
Lp = 0.191;
r = 0.0826;
Jm = 3e-5;
Marm = 0.028;
g = 9.81;
Jeq = 1.23e-4;
Jp = 1.1e-4;
Beq = 0;
Bp = 0;
Rm = 3.3;
Kt = 0.02797;
Km = 0.02797;

A32 = (r*Mp*Mp*lp*lp*g)/((Jp*Jeq) + (Mp*lp*lp*Jeq) + (Jp*Mp*r*r));
A33 = (Kt*Km*(Jp + Mp*lp*lp))/(Rm*((Jp*Jeq) + (Mp*lp*lp*Jeq) + (Jp*Mp*r*r)));
A42 = Mp*lp*g*(Jeq + (Mp*r*r))/((Jp*Jeq) + (Mp*lp*lp*Jeq) + (Jp*Mp*r*r));
A43 = -(Mp*lp*Kt*r*Km)/(Rm*((Jp*Jeq) + (Mp*lp*lp*Jeq) + (Jp*Mp*r*r)));
B3 = (Kt*(Jp + (Mp*lp*lp)))/(Rm*((Jp*Jeq) + (Mp*lp*lp*Jeq) + (Jp*Mp*r*r)));
B4 = (Mp*lp*Kt*r)/(Rm*((Jp*Jeq) + (Mp*lp*lp*Jeq) + (Jp*Mp*r*r)));

A = [0 0 1 0 ; 0 0 0 1; 0 A32 A33 0; 0 A42 A43 0];
B = [0 ; 0 ; B3 ; B4];
C = eye(4);
D = [0;0;0;0];

sys = ss(A, B, C, D);
q1 = 200;
q2 = 1;
q3 = 10;
q4 = 2;
Q = [q1 0 0 0; 0 q2 0 0; 0 0 q3 0; 0 0 0 q4];
R = 1;
Q = Q/sqrt(sqrt(q1*q2*q3*q4));

[K, S, P] = lqr(sys, Q, R)

sys2 = ss(A-B*K, zeros(4,1), C, D);
%step(sys2);
%initial(sys2, zeros(4,1));
%initial(sys2, [0; 0.1; 0; 0]);

